package com.haduart.rest;


public class EntryPointServiceTest {
}
