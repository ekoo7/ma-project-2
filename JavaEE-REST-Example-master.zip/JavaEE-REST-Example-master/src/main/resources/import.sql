insert into Members (email, amount) values ('haduart@gmail.com', 200)
insert into Members (email, amount) values ('eduard.cespedes@gmail.com', 300)
